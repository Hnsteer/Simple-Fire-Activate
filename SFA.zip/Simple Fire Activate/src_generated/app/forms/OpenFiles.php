<?php
namespace app\forms;

use std, gui, framework, app;


class OpenFiles extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		open(uiText($this->fileChooser));

        
    }

}
