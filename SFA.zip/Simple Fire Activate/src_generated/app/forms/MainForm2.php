<?php
namespace app\forms;

use windows;
use std, gui, framework, app;
use php\gui\UXDialog; 


class MainForm2 extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		UXDialog::show('Папка с режимом бога успешно создана на диске C');

       fs::makeDir('C:/GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}');
    } 

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		UXDialog::show('Диспетчер Задач Успешно Разблокирован');

        WindowsScriptHost::cmd("REG add HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System /v DisableTaskMgr /t REG_DWORD /d /0 /f. 15");
    }


    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		open('C:/GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}');

       
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		execute('C:\Windows\SysWOW64\cmd.exe', false);
		app()->showForm('CMD');

        
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm');

        
    }


     
     
}        
