<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\UXDialog; 
use action\Element; 
use php\io\Stream; 


class Browser extends AbstractForm
{

    /**
     * @event browser.load 
     */
    function doBrowserLoad(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		UXDialog::show('Браузер плохого качества');

        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::loadContentAsync($this->browser, $GLOBALS['restart'], function () use ($e, $event) {
		});

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::loadContentAsync($this->browser, uiText($this->edit), function () use ($e, $event) {
		});

        
    }

}
