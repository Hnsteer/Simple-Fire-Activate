<?php
namespace app\forms;

use bundle\windows\result\taskResult;
use bundle\windows\result\taskItem;
use windows;
use std, gui, framework, app;
use php\gui\UXDialog; 


class TaskMGR extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
       $this->textArea->text = WindowsScriptHost::cmd("tasklist");
    }

    /**
     * @event edit.globalKeyDown-Enter 
     */
    function doEditGlobalKeyDownEnter(UXKeyEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		UXDialog::show('Процесс успешно был снять с задачи');

        $a = $this->edit->text;     
        execute("Taskkill /IM $a /F");
    }



   
}
