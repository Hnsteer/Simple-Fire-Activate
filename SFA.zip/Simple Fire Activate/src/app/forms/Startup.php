<?php
namespace app\forms;

use windows;
use std, gui, framework, app;


class Startup extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        global $b3,$paht_reg,$paht_reg2;
        obnn_all();
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        delet_keys_("HKEY_LOCAL_MACHINE",c("textArea"));
    }



  
}
