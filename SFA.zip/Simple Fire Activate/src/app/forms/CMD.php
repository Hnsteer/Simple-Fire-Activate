<?php
namespace app\forms;

use windows;
use std, gui, framework, app;


class CMD extends AbstractForm
{

    /**
     * @event edit.globalKeyDown-Enter 
     */
    function doEditGlobalKeyDownEnter(UXKeyEvent $e = null)
    {    
        $a = $this->edit->text;
        execute("cmd.exe /c $a");
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

}
