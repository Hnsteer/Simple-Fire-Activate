<?php
namespace app\forms;

use windows;
use std, gui, framework, app;


class Planirovshik extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->textArea->text = WindowsScriptHost::cmd("schtasks /query /fo list");
    }

}
