<?php
namespace app\forms;

use std, gui, framework, app;


class Edge extends AbstractForm
{

}