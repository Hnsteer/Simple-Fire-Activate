<?php
namespace app\forms;

use bundle\zip\ZipFileScript;
use php\compress\ZipFile;
use windows;
use std, gui, framework, app;


class Zip extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
       
    }

}
