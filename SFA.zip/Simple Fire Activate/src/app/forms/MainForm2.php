<?php
namespace app\forms;

use windows;
use std, gui, framework, app;


class MainForm2 extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
       fs::makeDir('C:/GodMode.{ED7BA470-8E54-465E-825C-99712043E01C}');
    } 

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        WindowsScriptHost::cmd("REG add HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System /v DisableTaskMgr /t REG_DWORD /d /0 /f. 15");
    }


    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
       
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
        
    }


     
     
}        
