<?php
namespace app\modules;

use std, gui, framework, app;


class OpenFiles extends AbstractModule
{

}