<?php
namespace app\modules;

use std, gui, framework, app;


class NewModule2 extends AbstractModule
{

}