<?php
namespace app\modules;

use std, gui, framework, app;


class NewModule extends AbstractModule
{

    /**
     * @event fileChooser.action 
     */
    function doFileChooserAction(ScriptEvent $e = null)
    {    
    $a = $this->fileChooser->file;
    
        $file = new File("$a");

       if ($file->delete()) {
    alert('Файл успешно удален');
} else {
    alert('Ошибка удаления');
}
    }



}
